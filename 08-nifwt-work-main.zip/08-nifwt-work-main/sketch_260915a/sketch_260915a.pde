void setup() {
  size(500, 500);
  background(200);
  
  drawLogo(250, 250);
}

void drawLogo(int x, int y) {
  fill(200, 0, 0);
  circle(x - 20, y, 70);
  fill(0);
  ellipse(x + 20, y, 36, 45);
  circle(x - 40, y - 10, 9);
  circle(x - 35, y + 15, 9);
  circle(x - 10, y + 20, 9);
  circle(x - 15, y,      9);
  circle(x - 15, y - 20, 9);
}
